package main;

public class Config {
    public static final String WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather";
    public static final String WEATHER_API_KEY = "05f5fef0c62c4987c4309bdca7fffb9e";

    public static final String EXCHANGE_API_URL = "http://api.exchangeratesapi.io/v1/latest";
    public static final String EXCHANGE_API_KEY = "UO3xJz1yEzJiIUW8dxuTym0gT9gAjGZ3";
}
